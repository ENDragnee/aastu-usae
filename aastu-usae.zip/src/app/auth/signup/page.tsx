import React from 'react'
import Signup from '@/components/signup'

const page = () => {
  return (
    <div>
        <Signup/>
    </div>
  )
}

export default page